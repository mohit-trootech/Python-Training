"""
 zip a directory (folder) into a ZIP file using shutil.make_archive().
"""

import shutil

shutil.make_archive("copy", format="zip", root_dir="")
