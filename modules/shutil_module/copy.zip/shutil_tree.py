import shutil

# shutil.copytree("NewDir", "diary")


shutil.rmtree("New")
