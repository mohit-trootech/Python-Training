path = "/home/trootech/Mohit/Python_Learning/modules/shutil_module/"
