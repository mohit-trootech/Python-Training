"""
 zip a directory (folder) into a ZIP file using shutil.make_archive().
"""

import shutil

shutil.unpack_archive("copy.zip", "/home/trootech/Mohit/")
