"""
shutil.chown: Change owner user and/or group of the given path.
"""

import shutil


def change_user():
    pass
